//
//  MathModel.m
//  test
//
//  Created by zkhz on 2016/12/1.
//  Copyright © 2016年 zkhz. All rights reserved.
//

#import "MathModel.h"

@implementation MathModel
@end
