//
//  MathWebView.h
//  test
//
//  Created by zkhz on 2016/11/29.
//  Copyright © 2016年 zkhz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
@interface MathWebView :WKWebView
@property (nonatomic,assign)CGFloat ratio;
- (instancetype)initWithLaTexCode:(NSString *)code;
@end
