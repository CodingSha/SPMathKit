//
//  ViewController.m
//  MathKitDemo
//
//  Created by zkhz on 2016/12/1.
//  Copyright © 2016年 zkhz. All rights reserved.
//

#import "ViewController.h"
#import "MathSubjectView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *str1 = @"2.求下面函数的结果<math>\\left( \\sum_{k=1}^n a_k b_k \\right)^2 \\leq \\left( \\sum_{k=1}^n a_k^2 \\right) \\left( \\sum_{k=1}^n b_k^2 \\right)</math>并把答案告诉我👌";
    NSString *str2 = @"3.这个题不需要做,大家看看就行了<math>f(x) = {x^2} - 3x - 18,x \\in \\left[ {1,8} \\right]</math>因为肯定没人能看懂的";
    NSString *str3 = @"4.<math>\\displaystyle= \\frac{k(k+1)}{2}+k+1</math>这个大家知道是什么吗?请写出答案吧";
    NSString *str4 = @"5.这么简单的题,你居然让1️⃣年级的我做<math>\\displaystyle=\\left(\\sum_{i=1}^{k}i\\right)+(k+1)</math>,但是我还是不会,过吧下一道.";
    NSString *test = @"1.求出<math>\\displaystyle= \\left(\\sum_{i=1}^{k}i\\right) +(k+1)</math>中你觉得最适合变成的那个人,<image>file:///Users/zkhz/Downloads/U600P42T4D73063F52DT20040616103841.jpg</image>并求出最不合适的那个人()";
    NSArray *arr = @[test,str1,str2,str3,str4];
    for (NSInteger i = 0; i < 5; i ++) {
        
        MathSubjectView *subject = [[MathSubjectView alloc]initWithFrame:CGRectMake(10, 30+130 * i, self.view.bounds.size.width - 20,0)];
        subject.font = [UIFont systemFontOfSize:12];
        subject.testStr = arr[i];
        [self.view addSubview:subject];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
