//
//  ZKSubjectView.h
//  YiMath
//
//  Created by 沙少盼 on 2017/2/23.
//  Copyright © 2017年 Lemon_Mr.H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZKSubjectView : UIView

/**
 latex code
 you must set codes when init instance!
 */
@property (nonatomic,copy)NSArray *codes;

/**
 init

 @param callBack height
 @return instance
 */
- (instancetype)initWithIndexPath:(NSIndexPath *)indexPath
                         CallBack:(void(^)(CGFloat height ,NSIndexPath *IndexPath))callBack;


/**
 init

 @param indexPath indexPath
 @param callBack height and indexpath
 @param isTitle istitle
 @return instance
 */
- (instancetype)initWithIndexPath:(NSIndexPath *)indexPath
                         CallBack:(void (^)(CGFloat, NSIndexPath *))callBack
                         withType:(BOOL)isTitle;
@end
