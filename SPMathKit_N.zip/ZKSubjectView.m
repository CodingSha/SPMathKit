//
//  ZKSubjectView.m
//  YiMath
//
//  Created by 沙少盼 on 2017/2/23.
//  Copyright © 2017年 Lemon_Mr.H. All rights reserved.
//

#import "ZKSubjectView.h"
#import "SubjectWebView.h"
@interface ZKSubjectView ()<WKNavigationDelegate>
@property (nonatomic,copy)void(^callBack)(CGFloat height,NSIndexPath *IndexPath);
@property (nonatomic,strong)NSIndexPath *indexPath;
@property (nonatomic,assign)BOOL isTitle;
@end
@implementation ZKSubjectView

- (instancetype)initWithIndexPath:(NSIndexPath *)indexPath
                         CallBack:(void (^)(CGFloat, NSIndexPath *))callBack{
    return [self initWithIndexPath:indexPath CallBack:callBack withType:YES];
}
- (instancetype)initWithIndexPath:(NSIndexPath *)indexPath
                         CallBack:(void (^)(CGFloat, NSIndexPath *))callBack
                         withType:(BOOL)isTitle{
    if (self = [super init]) {
        _isTitle = isTitle;
        _callBack  = [callBack copy];
        _indexPath = indexPath;
    }
    return self;
}
- (void)setCodes:(NSArray *)codes{
    if (codes) {
        _codes = [codes copy];
        [self createUI];
    }
}
- (void)createUI{
    SubjectWebView *web = [[SubjectWebView alloc]initWithHTMLs:_codes
                                          MathRenderEngineType:MathRenderEngineTypeLatexCode withType:_isTitle];
    web.navigationDelegate = self;
    //嵌入tableView时，滑动性能优化
    [self performSelector:@selector(addSubview:)
               withObject:web
               afterDelay:0
                  inModes:@[NSDefaultRunLoopMode]];
    
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(web).with.offset(0);
    }];
}
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    NSLog(@"start...")
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    NSLog(@"end...")
    [webView evaluateJavaScript:@"document.body.scrollHeight"
              completionHandler:^(id _Nullable re, NSError * _Nullable error) {
                  
                  CGFloat height    = [re floatValue];
                  CGRect frame      = webView.frame;
                  frame.size.height = height;
                  webView.frame     = frame;
                  _callBack(height,_indexPath);
                  NSLog(@"%f",height)
    }];
}
@end
