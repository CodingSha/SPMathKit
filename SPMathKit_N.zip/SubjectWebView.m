//
//  SubjectWebView.m
//  YiMath
//
//  Created by 沙少盼 on 2017/2/23.
//  Copyright © 2017年 Lemon_Mr.H. All rights reserved.
//

#import "SubjectWebView.h"
#import "NSString+SSPExt.h"

@implementation SubjectWebView

- (instancetype)initWithHTMLs:(NSArray *)codes MathRenderEngineType:(MathRenderEngineType)type{
    return [self initWithHTMLs:codes MathRenderEngineType:type withType:YES];
}

- (instancetype)initWithHTMLs:(NSArray *)codes MathRenderEngineType:(MathRenderEngineType)type withType:(BOOL)isTitle{
    WKWebViewConfiguration *configer = [[WKWebViewConfiguration alloc]init];
    // 自适应屏幕宽度js
    NSString *jSString               = @"var meta = document.createElement('meta');\
    meta.setAttribute('name', 'viewport');\
    meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no', 'height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');\
    document.getElementsByTagName('head')[0].appendChild(meta);";
    WKUserScript *wkUserScript       = [[WKUserScript alloc] initWithSource:jSString
                                                              injectionTime:WKUserScriptInjectionTimeAtDocumentEnd
                                                           forMainFrameOnly:NO];
    // 添加自适应屏幕宽度js调用的方法
    [configer.userContentController addUserScript:wkUserScript];
    CGRect frame = CGRectMake(8, 0, SCREEN_WIDTH - 16, 0);
    if (!isTitle) {
        frame = CGRectMake(8, 0, SCREEN_WIDTH - 16 - 35 - 8, 0);
    }
    if (self = [super initWithFrame:frame configuration:configer]) {
        self.type = type;
        [self configerSelf];
        NSMutableArray *newCodes = @[].mutableCopy;
        for (NSInteger i = 0; i < codes.count; i++) {
            if (i != 0) {
                NSString *new_code = [NSString stringWithFormat:@"%c. %@",i + 64,codes[i]];
                [newCodes addObject:new_code];
            }else{
                [newCodes addObject:[@"&nbsp;&nbsp;&nbsp;&nbsp;" stringByAppendingString:codes[i]]];
            }
        }
        NSString *htmlStr = [self getHTMLStrings:newCodes];
        NSString *path    = [[NSBundle mainBundle] bundlePath];
        NSURL *baseURL    = [NSURL fileURLWithPath:path];
        [self loadHTMLString:htmlStr baseURL:baseURL];
    }
    return self;
}
/**
 配置webview
 */
- (void)configerSelf{
    self.scrollView.bounces = 0;
    self.scrollView.showsVerticalScrollIndicator = 0;
    self.scrollView.showsHorizontalScrollIndicator = 0;
    self.scrollView.scrollEnabled = 0;
}
- (NSString *)getHTMLStrings:(NSArray *)codes{
    NSString *html            = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Subject"
                                                                                                   ofType:@"html"]
                                                          encoding:NSUTF8StringEncoding
                                                             error:nil];
    NSMutableArray *newDIVs   = @[].mutableCopy;
    NSMutableArray *newSripts = @[].mutableCopy;
    NSInteger idex            = 0;
    for (NSString *code in codes) {
        NSArray *texts               = [code componentsSeparatedByString:@"@"];
        NSMutableArray *newCodes     = @[].mutableCopy;
        NSMutableArray *script_codes = @[].mutableCopy;
        for (NSString *sub in texts) {
            if ([sub hasPrefix:@"math#"]) {
                NSString *latex   = [sub stringByReplacingOccurrencesOfString:@"math#" withString:@""];
                NSData *data      = [[NSData alloc]initWithBase64EncodedString:latex options:0];
                NSString *reStr   = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                if (!data) {
                    reStr         = latex;
                }
                
                //将公式包裹进<span>标签
                NSString *new_sub = [NSString stringWithFormat:@"<span id='mykatex_%zd'>",idex];
                new_sub           = [new_sub stringByAppendingString:reStr];
                new_sub           = [new_sub stringByAppendingString:@"</span>"];
                //特殊处理方程组的加载
                if (([reStr containStr:@"begin{Bmatrix}"]&&[reStr containStr:@"end{matrix}"])||[reStr containStr:@"begin{cases}"]) {
                    NSString *url = [NSString stringWithFormat:@"http://latex.codecogs.com/png.download?%@",[NSString URLEncodedString:reStr]];
                    //加载图片
                    new_sub = [NSString stringWithFormat:@"<img src='%@'>",url];
                }
                [newCodes addObject:new_sub];
                
                //制作script渲染
                [script_codes addObject:[NSString stringWithFormat:@"katex.render('%@',mykatex_%zd);",reStr,idex]];
                idex ++;
            }else if([sub hasPrefix:@"/math#"]){
                NSString *new_sub = [sub stringByReplacingOccurrencesOfString:@"/math#" withString:@""];
                [newCodes addObject:new_sub];
            }else if ([sub hasPrefix:@"image#"]) {
                //加载图片
                NSString *new_sub = [NSString stringWithFormat:@"<img src='%@'>",[[sub stringByReplacingOccurrencesOfString:@"image#" withString:@""] componentsSeparatedByString:@";"][0]];
                [newCodes addObject:new_sub];
            }else if ([sub hasPrefix:@"/image#"]){
                NSString *new_sub = [sub stringByReplacingOccurrencesOfString:@"/image#" withString:@""];
                [newCodes addObject:new_sub];
            }else{
                [newCodes addObject:sub];
            }
        }
        if (newCodes.count) {
            [newDIVs addObject:newCodes];
        }
        if (script_codes.count) {
            [newSripts addObject:script_codes];
        }
    }
    
    NSString *code = @"";
    if (newDIVs.count) {
        //添加处理之后的标签
        for (NSArray *div in newDIVs) {
            code = [code stringByAppendingString:[[@"<div style='margin-top:5px;'>" stringByAppendingString:[div componentsJoinedByString:@""]] stringByAppendingString:@"</div>"]];
        }
    }
    if (newSripts.count) {
        //添加script渲染
        NSString *script = @"";
        for (NSArray *scripts in newSripts) {
            script       = [script stringByAppendingString:[scripts componentsJoinedByString:@""]];
        }
        html             = [html stringByReplacingOccurrencesOfString:@"script_mykatex" withString:script];
    }
    html                 = [html stringByReplacingOccurrencesOfString:@"@mykatex#" withString:code];
    html                 = [html stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
    return html;
}
@end
