//
//  SubjectWebView.h
//  YiMath
//
//  Created by 沙少盼 on 2017/2/23.
//  Copyright © 2017年 Lemon_Mr.H. All rights reserved.
//

#import <WebKit/WebKit.h>
typedef NS_ENUM(NSInteger,MathRenderEngineType) {
    MathRenderEngineTypeLatexCode = 0,//latex渲染
    MathRenderEngineTypeMathMLCode,//MathML渲染
    MathRenderEngineTypeImageData//图片渲染
};
@interface SubjectWebView : WKWebView

@property (nonatomic,assign)MathRenderEngineType type;

/**
 init
 
 @param codes HTMLString
 
 @param type RenderEngineType,include two type.
        tpye MathRenderEngineTypeLatexCode is Latex code
        type MathRenderEngineTypeMathMLCode is MathML code
 
 @return WKWebview instancetype
 */
- (instancetype)initWithHTMLs:(NSArray *)codes
        MathRenderEngineType:(MathRenderEngineType)type;


/**
 init

 @param codes HTMLString
 @param type RenderEngineType,include two type.
        tpye MathRenderEngineTypeLatexCode is Latex code
        type MathRenderEngineTypeMathMLCode is MathML code
 @param isTitle is title
 @return WKWebView instance
 */
- (instancetype)initWithHTMLs:(NSArray *)codes
         MathRenderEngineType:(MathRenderEngineType)type
                     withType:(BOOL)isTitle;
@end
